<?php $__env->startSection('content'); ?>
            <h2><?php echo e(\Request::route()->getName()); ?></h2>
            <form id="editWorkForm" method="POST" action="/api/update-portfolio-entry/<?php echo e($data->id); ?>">
                <?php echo e(csrf_field()); ?>

                 <input type="hidden" name="_method" value="PUT">
                <div class="form-group">
                    <label for="title">Title:</label>
                <input type="text" class="form-control" name="title" value="<?php echo e($data->title); ?>">
                   <div class="my-3 d-none alert alert-warning error error-title" role="alert">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="type">Type:</label>
                        <select class="form-control" id="type" name="type" >
                            <?php $__currentLoopData = $type_dropdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(strtolower($type) == $data->type): ?>
                                    <option selected value="<?php echo e(strtolower($type->name)); ?>"><?php echo e($type->name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e(strtolower($type->name)); ?>"><?php echo e($type->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                   <div class="my-3 d-none alert alert-warning error error-type" role="alert">
                    </div>
                </div>
                <!-- File Selector -->
                <script type="text/javascript" src="/js/imagePreview.js"></script>
                <img id="imgPreview" class="img-fluid" src="/storage/<?php echo e($data->portfolio_entries->filename_1); ?>" alt="image preview">

                <div class="form-group">
                    <label for="file_1">Image:</label>
                    <input type="file" class="form-control" id="file_1" name="file_1" onchange='previewImageToUpload("file_1", "imgPreview")'>
                   <div class="my-3 d-none alert alert-warning error error-file" role="alert">
                    </div>
                </div>
                <!-- File Selector END -->           
                                
                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea  id="article-ckeditor" type="text" id="summernote" class="form-control" id="description" name="description"><?php echo e($data->description); ?> </textarea>
                    <div class="my-3 d-none alert alert-warning error error-description" role="alert">
                    </div>
                </div>
                <div class="form-group">
                    <label for="website_url">Website Url:</label>
                    <input type="text" class="form-control" name="website_url" value="<?php echo e($data->website_url); ?> ">
                   <div class="my-3 d-none alert alert-warning error error-website-url" role="alert">
                    </div>
                </div>
                <?php if($skill_set !== null): ?>
                <div>Project Technologies:</div>

                    <?php if(!json_decode($data->technologies)): ?>
                        <?php $__currentLoopData = $skill_set; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill_set_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                <div class="form-group">
                                    <label for="<?php echo e($skill_set_item->name); ?>"><?php echo e($skill_set_item->name); ?></label>
                                    <input type="checkbox" id="<?php echo e($skill_set_item->name); ?>" value="<?php echo e($skill_set_item->name); ?>" name="technologies[]<?php echo e($skill_set_item->name); ?>">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php else: ?>
                        <?php $__currentLoopData = $skill_set; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill_set_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = json_decode($data->technologies); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technology_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($skill_set_item->name === $technology_item  ): ?>
                                    <div class="form-group">
                                        <label for="<?php echo e($skill_set_item->name); ?>"><?php echo e($skill_set_item->name); ?></label>
                                        <input type="checkbox" checked id="<?php echo e($skill_set_item->name); ?>" value="<?php echo e($skill_set_item->name); ?>" name="technologies[]<?php echo e($skill_set_item->name); ?>">
                                    </div>
                                <?php else: ?>
                                    <div class="form-group">
                                        <label for="<?php echo e($skill_set_item->name); ?>"><?php echo e($skill_set_item->name); ?></label>
                                        <input type="checkbox" id="<?php echo e($skill_set_item->name); ?>" value="<?php echo e($skill_set_item->name); ?>" name="technologies[]<?php echo e($skill_set_item->name); ?>">
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endif; ?>
                <button type="submit" class="btn btn-primary">Edit</button>
            </form>
    </form>
    <?php echo $__env->make('backend.partials.ckeditor', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>