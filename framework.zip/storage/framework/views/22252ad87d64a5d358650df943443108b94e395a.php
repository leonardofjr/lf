<?php $__env->startSection('content'); ?>
            <h2><?php echo e(\Request::route()->getName()); ?></h2>
            <form id="addWorkForm" method="POST" enctype="multipart/form-data" action="/api/post-portfolio-entry">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="title">Title:</label>
                    <input type="text" class="form-control" name="title" >
                   <div class="my-3 d-none alert alert-warning error error-title" role="alert">
                    </div>
                </div>
                 <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">

                <div class="form-group">
                    <label for="type">Type:</label>
                        <select class="form-control"  name="type" >
                            <?php $__currentLoopData = $type_dropdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e(strtolower($type->name)); ?>"><?php echo e($type->name); ?></option>
                      
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                   <div class="my-3 d-none alert alert-warning error error-type" role="alert">
                    </div>
                </div>
                <!-- File Selector -->
                <script type="text/javascript" src="/js/imagePreview.js"></script>
                <img id="imgPreview" class="img-fluid" src="https://via.placeholder.com/350x150" alt="image preview">

                <div class="form-group">
                    <label for="file_1">Image:</label>
                    <input type="file" class="form-control" id="file_1" name="file_1" onchange='previewImageToUpload("file_1", "imgPreview")'>
                   <div class="my-3 d-none alert alert-warning error error-file" role="alert">
                    </div>
                </div>
                <!-- File Selector END -->      
                                
                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea  id="article-ckeditor" type="text" class="form-control"  name="description" ></textarea>
                    <div class="my-3 d-none alert alert-warning error error-description" role="alert">
                    </div>
                </div>

                <div class="form-group">
                    <label for="website_url">Website Url:</label>
                    <input type="text" class="form-control" name="website_url" >
                   <div class="my-3 d-none alert alert-warning error error-website-url" role="alert">
                    </div>
                </div>     
                <?php if(!$skill_set == '[]'): ?>          

                <?php else: ?> 
                    <div>Project Technologies:</div>
                    <?php $__currentLoopData = $skill_set; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill_set_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group">
                            <label for="<?php echo e($skill_set_item->name); ?>"><?php echo e($skill_set_item->name); ?></label>
                            <input type="checkbox" id="<?php echo e($skill_set_item->name); ?>" value="<?php echo e($skill_set_item->name); ?>" name="technologies[]">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <button type="submit" class="btn btn-primary">Add</button>
            </form>
        <?php echo $__env->make('backend.partials.ckeditor', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>