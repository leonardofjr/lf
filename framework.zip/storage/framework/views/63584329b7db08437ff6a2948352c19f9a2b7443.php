<?php $__env->startSection('content'); ?>
        <h2><?php echo e(\Request::route()->getName()); ?><a class="btn-primary btn mx-4" href="<?php echo e(route('Add Portfolio Entry')); ?>">Add Portfolio Entry</a></h2>
          <div class="col-12">
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">Title</th>
                    <th scope="col">Author</th>
                    <th scope="col">Type</th>
                    <th scope="col">Created At</th>
                    <th scope="col">Edit</th>
                    <th scope="col">Delete</th>
                </tr>
                </thead>
            <tbody>
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item['title']); ?></td>
                    <td><?php echo e($item['author']); ?></td>
                    <td><?php echo e($item['type']); ?></td>
                    <td><?php echo e($item['created_at']); ?></td>
                    <td><a href="/admin/portfolio/edit/<?php echo e($item['id']); ?>" class="fas fa-edit"></a></td>
                    <td>
                        <form id="deleteWorkForm" class="d-inline-block" action="/api/delete-portfolio-entry/<?php echo e($item['id']); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                                <button type="submit" class="fas fa-trash"></button>
                        </form>
                    </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tbody>
        </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>