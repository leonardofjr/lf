<?php $__env->startSection('content'); ?>
            <h2><?php echo e(\Request::route()->getName()); ?></h2>
                <form id="setupPageForm" method="POST" enctype="multipart/form-data" action="/api/update-user-settings/<?php echo e($id); ?>">
                    <div class="form-group">
                        <label for="fname">First Name:</label>
                        <input type="text" class="form-control" id="fname" name="fname" value="<?php echo e($data->fname); ?>" >
                    </div>
                    <div class="form-group">
                        <label for="lname">Last Name:</label>
                        <input type="text" class="form-control" id="lname" name="lname" value="<?php echo e($data->lname); ?>" >
                    </div>
                    <script type="text/javascript" src="/js/imagePreview.js"></script>
                    <input name="_method" type="hidden" value="PUT">
                    <?php echo e(csrf_field()); ?>

                    <?php if(!is_file(public_path('/storage\\' . $data->profile_image))): ?>             <p>Avatar Image:</p>
                        <img id="avatarPreview" class="img-fluid" src="https://via.placeholder.com/300" alt="image preview">
                    <?php else: ?> 
                      <p>Avatar Image:</p>
                      <img id="avatarPreview" class="img-fluid" src="/storage/<?php echo e($data->profile_image); ?>" alt="image preview">
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="profile_image">Change Image:</label>
                        <input type="file" id="profile_image" name="profile_image" accept="image/*" onchange='previewImageToUpload("profile_image", "avatarPreview")'>
                        <div class="my-3 d-none alert alert-warning error error-profile-image" role="alert"></div>
                    </div>
                    <div class="my-3 d-none alert alert-warning error error-image" role="alert">
                    </div>
                    <div class="form-group">
                        <label for="article-ckeditor">Bio:</label>
                        <textarea id="article-ckeditor" class="form-control" name="bio"><?php echo e($data->bio); ?></textarea>
                        <div class="my-3 d-none alert alert-warning error error-bio" role="alert"></div>
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone:</label>
                    <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo e($data->phone); ?>" >
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo e($data->email); ?>" >
                    </div>

                    <div class="form-group">
                        <label for="facebook_url">Facebook Url:</label>
                        <input type="text" class="form-control" id="facebook_url" name="facebook_url" value="<?php echo e($data->facebook_url); ?>" >
                    </div>
                    <div class="form-group">
                        <label for="linkedin_url">Linkedin Url:</label>
                        <input type="text" class="form-control" id="linkedin_url" name="linkedin_url" value="<?php echo e($data->linkedin_url); ?>" >
                    </div>
                    <div class="form-group">
                        <label for="twitter_url">Twitter Url:</label>
                        <input type="text" class="form-control" id="twitter_url" name="twitter_url" value="<?php echo e($data->twitter_url); ?>" >
                    </div>
                    <div class="form-group">
                        <label for="github_url">Github Url:</label>
                        <input type="text" class="form-control" id="github_url" name="github_url" value="<?php echo e($data->github_url); ?>" >
                    </div>
                    <button type="submit" class="btn btn-primary">Save</button>
                </form>
            <?php echo $__env->make('backend.partials.ckeditor', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>