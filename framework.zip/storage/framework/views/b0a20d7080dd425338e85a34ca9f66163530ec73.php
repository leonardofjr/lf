<?php $__env->startSection('content'); ?>
            <h2><?php echo e(\Request::route()->getName()); ?></h2>
            <form id="profileSettingsForm" method="POST" action="/api/update-setup-skills/<?php echo e($data->id); ?>">
                <?php echo e(csrf_field()); ?>

                <input name="_method" type="hidden" value="PUT">
                <div class="form-group">
                    <label for="title">Skills & Offer:</label>
                    <textarea id="article-ckeditor" class="form-control" name="skills_and_offer"><?php echo e($data->skills_and_offer); ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Save</button>
            </form>
        <?php echo $__env->make('backend.partials.ckeditor', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>