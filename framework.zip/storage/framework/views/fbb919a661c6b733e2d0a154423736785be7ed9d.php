<?php $__env->startSection('content'); ?>
<div class="row">
          <div class="offset-10">
              <a class="btn-primary btn" href="<?php echo e(route('Add Portfolio Entry')); ?>">Add Portfolio Entry</a>
          </div>
          <div class="col-12">
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="row">
                        <?php $__currentLoopData = $item['files']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3">
                            <img src="<?php echo e(asset('storage/' . $file['filename_1'])); ?>" class="img-fluid">
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-md-9">
                            <h2><?php echo e($item['title']); ?></h2>
                            <p><strong>Project Description: </strong><?php echo $item['description']; ?></p>
                            <p><strong>Website: </strong><a href="<?php echo e($item['website_url']); ?>"><?php echo e($item['website_url']); ?></a></p>
                            <?php if($item['technologies'] && $skill_set !== null): ?> 
                            <span><strong>Technologies:</strong></span>
                                <ul class="list-unstyled d-inline-block"> 
                                <?php $__currentLoopData = $item['technologies']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technology_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $skill_set; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill_set_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($skill_set_item->name === $technology_item): ?>
                                <li  class="d-inline-block"><a href="<?php echo e($skill_set_item->website); ?>"><?php echo e($technology_item); ?></a>,</li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            
                            <?php endif; ?>
                            </p>
                        </div>
                </div>

                <div class="offset-11">
                <a href="/admin/portfolio/edit/<?php echo e($item['id']); ?>" class="fas fa-edit"></a>
                <form id="deleteWorkForm" class="d-inline-block" action="/api/delete-portfolio-entry/<?php echo e($item['id']); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                      <button type="submit" class="fas fa-trash"></button>
                </form>
                   
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after-body-scripts'); ?>
<script src="../../../dist/scripts/scripts.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>