<?php $__env->startSection('content'); ?>
            <section class="container"> 
                <h2>Start Page</h2>
               <h3>Set your skills</h2>
                <form id="profileSettingsForm" method="POST" enctype="multipart/form-data" action="/api/post-user-settings">
                    <?php echo e(csrf_field()); ?>

                    <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group">
                            <label for="title"><?php echo e($skill['name']); ?></label>
                        <input type="range" class="form-control" id="<?php echo e($skill['value']); ?>}" name="<?php echo e($skill['value']); ?>" value="0" onchange='evalSlider(this.id)'>
                        <output></output>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
                    <button type="submit" class="btn btn-primary">Save</button>
                </form>
            </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>