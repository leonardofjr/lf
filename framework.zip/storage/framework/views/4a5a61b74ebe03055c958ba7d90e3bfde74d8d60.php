    <li><a href="/profile">Profile</a></li>
    <li><a href="/home">Home</a></li>
