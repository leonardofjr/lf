<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    
<?php $__env->startSection('content'); ?>
<div class="row">
          <div class="offset-11">
           <a class="btn-primary btn" href="/admin/work/add">Add Work</a>
          </div>
          <div class="col-12">
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h2><?php echo e($item['title']); ?></h2>
                <p><?php echo e($item['description']); ?></p>
                <p><strong>Images:</strong>
                        <?php $__currentLoopData = $item['files']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="/assets/uploads/<?php echo e($file['filename_1']); ?>" class="img-fluid">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
                <p><strong>Technologies:</strong>
                    <?php $__currentLoopData = json_decode($item['technologies']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technoloogy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($technoloogy); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
                <div class="offset-11">
                <a href="work/edit/<?php echo e($item['id']); ?>">Edit</a>
                <form id="deleteWorkForm" action="work/delete/<?php echo e($item['id']); ?>" method="DELETE">
                      <?php echo e(csrf_field()); ?>

                     <input type="hidden" name="_method" value="DELETE">
                      <button type="submit">Delete</button>
                </form>
                   
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after-body-scripts'); ?>
<script src="../../../dist/scripts/scripts.js"></script>
<?php $__env->stopSection(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>