<?php $__env->startSection('content'); ?>
            <section class="container"> 
            <h2><?php echo e(\Request::route()->getName()); ?></h2>
                <form id="setupSkillsForm" method="POST" enctype="multipart/form-data" action="/api/post-setup-skills">
                    <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                        <div class="form-group">
                            <label for="title">Skills & Offer:</label>
                            <textarea id="article-ckeditor" class="form-control" name="skills_and_offer" ></textarea>
                        </div>
                    <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group">
                            <label for="title"><?php echo e($skill['name']); ?></label>
                        <input type="range" class="form-control" id="<?php echo e($skill['value']); ?>}" name="<?php echo e($skill['value']); ?>" value="0" onchange='evalSlider(this.id)'>
                        <output></output>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
                    <button type="submit" class="btn btn-primary">Save</button>
                </form>
            </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>