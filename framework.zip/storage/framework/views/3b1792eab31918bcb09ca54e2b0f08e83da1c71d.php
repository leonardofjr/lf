<?php $__env->startSection('content'); ?>
            <section class="container"> 
            <h2>Add Work</h2>
            <form id="addWorkForm" method="POST" enctype="multipart/form-data" action="/admin/work/add-new-work-post">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="title">Title:</label>
                    <input type="text" class="form-control" id="title" name="title" >
                    <div class="alert alert-warning mt-2 flash-message-title d-none">
                        <span></span>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="type">Type:</label>
                        <select class="form-control" id="type" name="type" >
                            <?php $__currentLoopData = $type_dropdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e(strtolower($type)); ?>"><?php echo e($type); ?></option>
                      
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    <div class="alert alert-warning mt-2 flash-message-type d-none">
                        <span></span>
                    </div>
                </div>
            
                <!-- File Selector -->
                <div class="form-group">
                    <label for="image">Image:</label>
                    <input type="file" class="form-control" name="image_1" >
                        <div class="alert alert-warning mt-2 flash-message-image d-none">
                        <span></span>
                    </div>
                </div>
        
      
                <div class="form-group">
                    <label for="image">Image:</label>
                    <input type="file" class="form-control" name="image_2" >
                        <div class="alert alert-warning mt-2 flash-message-image d-none">
                        <span></span>
                    </div>
                </div>
        
      
                <div class="form-group">
                    <label for="image">Image:</label>
                    <input type="file" class="form-control" name="image_3" >
                        <div class="alert alert-warning mt-2 flash-message-image d-none">
                        <span></span>
                    </div>
                </div>
        
      
        
                <!-- File Selector END -->
                                
                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea type="text" class="form-control" id="description" name="description" ></textarea>
                        <div class="alert alert-warning mt-2 flash-message-description d-none">
                        <span></span>
                    </div>
                </div>
                <div class="form-group">
                    <label for="technologies_used">Technologies used:</label>
                    <!-- Looping through $languages passed by controller -->
                    <?php $__currentLoopData = $programming_languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                                <input type="checkbox" class="form-check-input" id= "<?php echo e(strtolower($language)); ?>" name="<?php echo e(strtolower($language)); ?>" value= "<?php echo e(strtolower($language)); ?>">
                                 <label class="form-check-label" for=<?php echo e(strtolower($language)); ?>><?php echo e($language); ?></label>
                        </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <button type="submit" class="btn btn-primary">Add</button>
            </form>
        </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after-body-scripts'); ?>
<script src="../../../dist/scripts/scripts.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>